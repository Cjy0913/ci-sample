rootProject.name = "sampleapp"
